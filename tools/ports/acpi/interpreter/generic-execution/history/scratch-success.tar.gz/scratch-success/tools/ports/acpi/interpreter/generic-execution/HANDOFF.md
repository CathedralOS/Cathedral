# Generic executor scratch handoff

Frozen source root: `/tmp/cathedral-aml-generic-execution-outcome-output-20260920`.
No canonical files have been published. Root reviews and authorizes publication;
canonical old receipts must remain historical and canonical realpath replay is
still required. No commits, push or task-board changes were made by this agent.

## Production files

- `source/libraries/acpi/interpreter/execution/control.omg`
- `source/libraries/acpi/interpreter/execution/decode_execution.omg`
- `source/libraries/acpi/interpreter/execution/engine.omg`
- `source/libraries/acpi/interpreter/execution/execution_model.omg`
- `source/libraries/acpi/interpreter/execution/external_arguments.omg`
- `source/libraries/acpi/interpreter/execution/frames.omg`
- `source/libraries/acpi/interpreter/execution/generic_binding_plan.omg`
- `source/libraries/acpi/interpreter/execution/generic_target_bridge.omg`
- `source/libraries/acpi/interpreter/execution/generic_target_model.omg`
- `source/libraries/acpi/interpreter/execution/generic_target_values.omg`
- `source/libraries/acpi/interpreter/execution/generic_targets.omg`
- `source/libraries/acpi/interpreter/execution/generic_values.omg`
- `source/libraries/acpi/interpreter/execution/integer_target_bridge.omg`
- `source/libraries/acpi/interpreter/execution/integer_target_values.omg`
- `source/libraries/acpi/interpreter/execution/operands.omg`
- `source/libraries/acpi/interpreter/execution/retire.omg`
- `source/libraries/acpi/interpreter/execution/runtime_model.omg`
- `source/libraries/acpi/interpreter/execution/targets.omg`
- `source/libraries/acpi/pipeline/program.omg`

New scope/inventory docs: `execution/generic.PORT.md` and
`execution/generic-inventory.json` under the interpreter package.

## Developer files

New `tools/ports/acpi/interpreter/generic-execution/` contains generated original
fixtures, focused cases, current/historical receipts and the source-bound manifest.
The four existing test files below have narrow API/harness changes:

- `tools/ports/acpi/interpreter/execution/fixtures.py`
- `tools/ports/acpi/interpreter/execution/main.omg`
- `tools/ports/acpi/interpreter/execution/check_interpreted.py`
- `tools/ports/acpi/pipeline/check.py`

The integer fixture preserves the original 79 cases and controls while adapting
Namespace to ObjectStore. Drivers can reuse an existing isolated binary without
Cargo, and assert source/binary stability. No existing historical verification
records were overwritten in canonical Cathedral.

## Current proof

- `verification.json`: 55 pairs, 962.73 s, checked interpreter.
- `integer-regression.json`: 79 pairs, 624.80 s, checked interpreter.
- `pipeline-regression.json`: 22 pairs, 836.55 s, checked interpreter.
- `arguments-verification.json`: 15 pairs, 45.98 s, checked interpreter.
- `decoder-verification.json`: 6 pairs, 106.85 s, checked interpreter.
- `entry-minimal-strict-verification.json`: 4 pairs, 552.96 s, checked interpreter.
- `entry-minimal-verification.json`: 2 pairs, 494.96 s, checked interpreter.
- `bridge-verification.json`: 3 pairs, 164.59 s, checked interpreter.
- `retirement-verification.json`: 2 pairs, 213.30 s, checked interpreter.
- `bridge-atomicity-verification.json`: 14 pairs, 183.70 s, checked interpreter.
- `binding-prediction-verification.json`: 64 pairs, 67.91 s, checked interpreter.
- `kernel-const-verification.json`: 1 pairs, 83.40 s, constant evaluator.

`evidence/verify.py` checks receipt hashes, every recorded source hash and actual
PASS counts. The representative const control is expected to fail its checked
requirement. The checked runner executes actual authored Omega; no native or
firmware run is represented. The generic, integer and pipeline suites passed
without splitting or weakening their original expectations.

The current internal target mutation helper returns unit and writes its typed
ExecutionOutcome to a local output. This source-shape change avoided repeated
nominal result-origin traversal without changing APIs, typed errors or mutation
policy. No numeric status encoding or Omega compiler edits were introduced.

Remaining limits and exact entry/alias/rollback policies are documented in
`generic.PORT.md`. Dynamic literals, general reference opcode dispatch, implicit
conversions, deep package clone, object reclamation, regions and services remain
outside this initial checkpoint.
