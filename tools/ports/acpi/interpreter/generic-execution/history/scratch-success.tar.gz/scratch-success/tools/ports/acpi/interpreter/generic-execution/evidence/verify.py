#!/usr/bin/env python3
"""Verify the retained source-bound scratch milestone; does not execute Omega."""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
ROOT = HERE.parents[4]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    manifest = json.loads((HERE / 'manifest.json').read_text())
    for relative, expected in manifest['production_source_sha256'].items():
        assert sha(args.root / relative) == expected, relative
    for item in manifest['current_receipts']:
        path = HERE / item['path']
        assert sha(path) == item['sha256'], path
        receipt = json.loads(path.read_text())
        snapshot = receipt.get('source_sha256', receipt.get('source_snapshot_sha256', {}))
        assert snapshot
        for relative, expected in snapshot.items():
            assert sha(args.root / relative) == expected, (path.name, relative)
        if item['stage'] == 'constant evaluator':
            results = receipt['results']
            assert len(results) == 2 and results[0]['exit_code'] == 0 and results[1]['exit_code'] != 0
            assert 'require' in results[1]['output'].lower()
        else:
            assert receipt.get('exit_code', 0) == 0
            assert receipt.get('source_unchanged', True)
            output = receipt['output']
            assert sum(line.startswith('PASS ') for line in output.splitlines()) == 2 * item['pairs']
            assert not any(line.startswith('FAIL ') for line in output.splitlines())
        print('PASS retained evidence:', item['path'], item['pairs'], 'pair(s)')
    print('PASS source/receipt integrity only; no new compiler or runtime execution')

if __name__ == '__main__':
    main()
